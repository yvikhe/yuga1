package com.tieto.dao;

import java.util.List;

import com.tieto.pojo.Contact;

public interface ContactDAO {
	public void addContact(Contact contact);
	public List<Contact> listContact();
	public void removeContact(int id);
	public Contact getContact(int id);
	public void updateContact(Contact contact);
}
